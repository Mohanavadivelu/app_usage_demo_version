const API_BASE_URL = 'http://127.0.0.1:8000/api/v1';
const API_KEY = 'CyRLgKg-FL7RuTtVvb7BPr8wmUoI1PamDj4Xdb3eT9w';
const API_KEY_HEADER = 'X-API-Key-725d9439';

// Common headers for API requests
const getHeaders = (additionalHeaders = {}) => ({
    [API_KEY_HEADER]: API_KEY,
    'Content-Type': 'application/json',
    ...additionalHeaders
});

export function getChartData() {
    return fetch(`${API_BASE_URL}/chart-data`, {
        headers: getHeaders()
    })
        .then(response => response.json());
}

// Application API functions
export function getApplications(page = 1, limit = 10, search = '') {
    const params = new URLSearchParams({
        skip: ((page - 1) * limit).toString(),
        limit: limit.toString()
    });
    
    if (search) {
        params.append('search', search);
    }
    
    return fetch(`${API_BASE_URL}/app_list?${params}`, {
        headers: getHeaders()
    })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            // Transform response to match frontend expectations
            const transformedApps = (data.app_list || []).map(app => ({
                ...app,
                id: app.app_id // Map app_id to id for frontend compatibility
            }));
            
            return {
                applications: transformedApps,
                total: data.total || 0,
                page: page,
                pages: Math.ceil((data.total || 0) / limit)
            };
        });
}

export function getApplication(id) {
    return fetch(`${API_BASE_URL}/app_list/${id}`, {
        headers: getHeaders()
    })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        });
}

export function createApplication(applicationData) {
    return fetch(`${API_BASE_URL}/app_list`, {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify(applicationData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    });
}

export function updateApplication(id, applicationData) {
    return fetch(`${API_BASE_URL}/app_list/${id}`, {
        method: 'PUT',
        headers: getHeaders(),
        body: JSON.stringify(applicationData)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    });
}

export function deleteApplication(id) {
    return fetch(`${API_BASE_URL}/app_list/${id}`, {
        method: 'DELETE',
        headers: getHeaders()
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    });
}
