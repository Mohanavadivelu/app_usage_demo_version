from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
import os

app = FastAPI()

# CORS configuration
origins = [
    "http://localhost",
    "http://localhost:8082",
    "http://localhost:8002",
    "http://127.0.0.1",
    "http://127.0.0.1:8002",
    "http://127.0.0.1:8082",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Get the absolute path to the admin_app directory
current_dir = os.path.dirname(os.path.abspath(__file__))

# Mount the static files
app.mount("/", StaticFiles(directory=current_dir, html=True), name="static")

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8002)
